package com.example.asm.manhinhcho;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

import com.example.asm.DAO.AdminDAO;
import com.example.asm.R;
import com.example.asm.activity.Login_Activity;
import com.example.asm.model.Admin;

import java.util.ArrayList;


public class Manhinhcho1 extends AppCompatActivity {

    private AdminDAO adminDAO;
    private ArrayList<Admin> arr = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.manhinhcho1);

        adminDAO = new AdminDAO(Manhinhcho1.this);
        arr = adminDAO.getAllAdmin();
        if(arr.size() == 0){
            adminDAO.insertadmin();
        }

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(getApplicationContext(), Login_Activity.class));
                finish();
            }
        },2000);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
    }
}