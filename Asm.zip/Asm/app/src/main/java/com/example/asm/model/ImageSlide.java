package com.example.asm.model;

public class ImageSlide {
    private int img;

    public ImageSlide(int img) {
        this.img = img;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }
}
