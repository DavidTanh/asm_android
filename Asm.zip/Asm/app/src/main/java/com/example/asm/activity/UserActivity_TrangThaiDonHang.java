package com.example.asm.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.asm.Fragments.tabFragments.Fragment_DHchoxuly;
import com.example.asm.Fragments.tabFragments.Fragment_DHdahoanthanh;
import com.example.asm.Fragments.tabFragments.Fragment_DHdanggiao;
import com.example.asm.Fragments.tabFragments.Fragment_DHxacnhan;
import com.example.asm.R;
import com.google.android.material.tabs.TabLayout;


public class UserActivity_TrangThaiDonHang extends AppCompatActivity {

    private ImageView imgbackTTDH;
    private TabLayout tabLayout_DHUser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_trangthai_donhang);
        imgbackTTDH = findViewById(R.id.imgBackTTDH);
        imgbackTTDH.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mIntent = new Intent(UserActivity_TrangThaiDonHang.this, KhachHang_Activity.class);
                mIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(mIntent);
            }
        });

        tabLayout_DHUser = findViewById(R.id.tab_layout_User);
        tabLayout_DHUser.addTab(tabLayout_DHUser.newTab().setText("Chờ xử lý"));
        tabLayout_DHUser.addTab(tabLayout_DHUser.newTab().setText("Đã xác nhận"));
        tabLayout_DHUser.addTab(tabLayout_DHUser.newTab().setText("Đang vẩn chuyển"));
        tabLayout_DHUser.addTab(tabLayout_DHUser.newTab().setText("Đã nhận"));

        if(tabLayout_DHUser.getTabAt(0).isSelected()){
            getSupportFragmentManager().beginTransaction().replace(R.id.container_fragDH_User, new Fragment_DHchoxuly()).commit();
        }
        tabLayout_DHUser.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if(tab.getPosition() == 0){
                    getSupportFragmentManager().beginTransaction().replace(R.id.container_fragDH_User, new Fragment_DHchoxuly()).commit();
                }else if(tab.getPosition() == 1){
                    getSupportFragmentManager().beginTransaction().replace(R.id.container_fragDH_User, new Fragment_DHxacnhan()).commit();
                }else if(tab.getPosition() == 2){
                    getSupportFragmentManager().beginTransaction().replace(R.id.container_fragDH_User, new Fragment_DHdanggiao()).commit();
                }
                else {
                    getSupportFragmentManager().beginTransaction().replace(R.id.container_fragDH_User, new Fragment_DHdahoanthanh()).commit();
                }
            }
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }
}