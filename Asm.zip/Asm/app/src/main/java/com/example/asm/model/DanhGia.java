package com.example.asm.model;

public class DanhGia {
    private int maDG;
    private int maUser;
    private int maSP;
    private int dangGia;
    private String nhanXet;

    public DanhGia() {
    }

    public int getMaDG() {
        return maDG;
    }

    public void setMaDG(int maDG) {
        this.maDG = maDG;
    }

    public int getMaUser() {
        return maUser;
    }

    public void setMaUser(int maUser) {
        this.maUser = maUser;
    }

    public int getMaSP() {
        return maSP;
    }

    public void setMaSP(int maSP) {
        this.maSP = maSP;
    }

    public int getDangGia() {
        return dangGia;
    }

    public void setDangGia(int dangGia) {
        this.dangGia = dangGia;
    }

    public String getNhanXet() {
        return nhanXet;
    }

    public void setNhanXet(String nhanXet) {
        this.nhanXet = nhanXet;
    }
}
