package com.example.asm.DAO;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.asm.database.DB_Store;
import com.example.asm.model.DonHang;

import java.util.ArrayList;



public class DonHangDAO {
    private SQLiteDatabase db;

    public DonHangDAO(Context context) {
        DB_Store db_store = new DB_Store(context);
        db = db_store.getWritableDatabase();
    }

    public long insert(DonHang donHang){
        ContentValues values = new ContentValues();
        values.put("maUser",donHang.maUser);
        values.put("maAdmin", donHang.maAdmin);
        values.put("ngay",donHang.ngay);
        values.put("tongTien",donHang.tongTien);
        values.put("trangThai",donHang.trangThai);
        values.put("trangThaiDG", donHang.trangThaiDG);
        values.put("ghiChu",donHang.ghiChu);
        return db.insert("HoaDon",null, values);
    }

    public long update(DonHang donHang){
        ContentValues values = new ContentValues();
        values.put("maUser",donHang.maUser);
        values.put("maAdmin", donHang.maAdmin);
        values.put("ngay",donHang.ngay);
        values.put("tongTien",donHang.tongTien);
        values.put("trangThai",donHang.trangThai);
        values.put("trangThaiDG", donHang.trangThaiDG);
        values.put("ghiChu",donHang.ghiChu);
        return db.update("HoaDon",values,"maHD=?",new String[]{String.valueOf(donHang.maHD)});
    }

    public int delete(String id){
        return db.delete("HoaDon", "maHD=?", new String[]{id});
    }

    public ArrayList<DonHang> getAllDonHang(){
        String sql = "SELECT * FROM HoaDon";
        return getData(sql);
    }

    public ArrayList<DonHang> getData(String sql, String...selectionArgs) {
        Cursor cursor = db.rawQuery(sql,selectionArgs);
        ArrayList<DonHang> arr = new ArrayList<>();
        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()){
                DonHang donHang = new DonHang();
                donHang.setMaHD(cursor.getInt(0));
                donHang.setMaUser(cursor.getInt(1));
                donHang.setMaAdmin(cursor.getString(2));
                donHang.setNgay(String.valueOf(cursor.getString(3)));
                donHang.setTongTien(cursor.getInt(4));
                donHang.setTrangThai(cursor.getInt(5));
                donHang.setTrangThaiDG(cursor.getInt(6));
                donHang.setGhiChu(cursor.getString(7));
                arr.add(donHang);
                cursor.moveToNext();
            }
        }
        return arr;
    }

    public ArrayList<DonHang> getDHchoxuly() {
        String sqlDH = "SELECT * FROM HoaDon WHERE trangThai = 0";
        Cursor cursor = db.rawQuery(sqlDH,null);
        ArrayList<DonHang> arr = new ArrayList<>();
        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()){
                DonHang donHang = new DonHang();
                donHang.setMaHD(cursor.getInt(0));
                donHang.setMaUser(cursor.getInt(1));
                donHang.setMaAdmin(cursor.getString(2));
                donHang.setNgay(cursor.getString(3));
                donHang.setTongTien(cursor.getInt(4));
                donHang.setTrangThai(cursor.getInt(5));
                donHang.setTrangThaiDG(cursor.getInt(6));
                donHang.setGhiChu(cursor.getString(7));
                arr.add(donHang);
                cursor.moveToNext();
            }
        }
        return arr;
    }

    public ArrayList<DonHang> getDHByTrangthai(int trangthai) {
        String sqlDH = "SELECT * FROM HoaDon WHERE trangThai = ?";
        Cursor cursor = db.rawQuery(sqlDH,new String[]{String.valueOf(trangthai)});
        ArrayList<DonHang> arr = new ArrayList<>();
        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()){
                DonHang donHang = new DonHang();
                donHang.setMaHD(cursor.getInt(0));
                donHang.setMaUser(cursor.getInt(1));
                donHang.setMaAdmin(cursor.getString(2));
                donHang.setNgay(cursor.getString(3));
                donHang.setTongTien(cursor.getInt(4));
                donHang.setTrangThai(cursor.getInt(5));
                donHang.setTrangThaiDG(cursor.getInt(6));
                donHang.setGhiChu(cursor.getString(7));
                arr.add(donHang);
                cursor.moveToNext();
            }
        }
        return arr;
    }

    public ArrayList<DonHang> getDHXacnhan() {
        String sqlDH = "SELECT * FROM HoaDon WHERE trangThai = 1";
        Cursor cursor = db.rawQuery(sqlDH,null);
        ArrayList<DonHang> arr = new ArrayList<>();
        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()){
                DonHang donHang = new DonHang();
                donHang.setMaHD(cursor.getInt(0));
                donHang.setMaUser(cursor.getInt(1));
                donHang.setMaAdmin(cursor.getString(2));
                donHang.setNgay(cursor.getString(3));
                donHang.setTongTien(cursor.getInt(4));
                donHang.setTrangThai(cursor.getInt(5));
                donHang.setTrangThaiDG(cursor.getInt(6));
                donHang.setGhiChu(cursor.getString(7));
                arr.add(donHang);
                cursor.moveToNext();
            }
        }
        return arr;
    }

    public ArrayList<DonHang> getDHdangGiao() {
        String sqlDH = "SELECT * FROM HoaDon WHERE trangThai = 2";
        Cursor cursor = db.rawQuery(sqlDH,null);
        ArrayList<DonHang> arr = new ArrayList<>();
        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()){
                DonHang donHang = new DonHang();
                donHang.setMaHD(cursor.getInt(0));
                donHang.setMaUser(cursor.getInt(1));
                donHang.setMaAdmin(cursor.getString(2));
                donHang.setNgay(cursor.getString(3));
                donHang.setTongTien(cursor.getInt(4));
                donHang.setTrangThai(cursor.getInt(5));
                donHang.setTrangThaiDG(cursor.getInt(6));
                donHang.setGhiChu(cursor.getString(7));
                arr.add(donHang);
                cursor.moveToNext();
            }
        }
        return arr;
    }

    public ArrayList<DonHang> getDHdahoanthanh() {
        String sqlDH = "SELECT * FROM HoaDon WHERE trangThai = 3";
        Cursor cursor = db.rawQuery(sqlDH,null);
        ArrayList<DonHang> arr = new ArrayList<>();
        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()){
                DonHang donHang = new DonHang();
                donHang.setMaHD(cursor.getInt(0));
                donHang.setMaUser(cursor.getInt(1));
                donHang.setMaAdmin(cursor.getString(2));
                donHang.setNgay(cursor.getString(3));
                donHang.setTongTien(cursor.getInt(4));
                donHang.setTrangThai(cursor.getInt(5));
                donHang.setTrangThaiDG(cursor.getInt(6));
                donHang.setGhiChu(cursor.getString(7));
                arr.add(donHang);
                cursor.moveToNext();
            }
        }
        return arr;
    }

    public long updateTrangThaiDonHang(int maHD, int newTrangThai) {
        ContentValues values = new ContentValues();
        values.put("trangThai", newTrangThai);
        return db.update("HoaDon", values, "maHD=?", new String[]{String.valueOf(maHD)});
    }

    public long updateTrangThaiDG(int maHD, int newTrangThai) {
        ContentValues values = new ContentValues();
        values.put("trangThaiDG", newTrangThai);
        return db.update("HoaDon", values, "maHD=?", new String[]{String.valueOf(maHD)});
    }

    public ArrayList<DonHang> getDHchoxulyByIDUser( int maUser) {
        String sqlDH = "SELECT * FROM HoaDon WHERE maUser = ? and trangThai = 0";
        Cursor cursor = db.rawQuery(sqlDH,new String[]{String.valueOf(maUser)});
        ArrayList<DonHang> arr = new ArrayList<>();
        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()){
                DonHang donHang = new DonHang();
                donHang.setMaHD(cursor.getInt(0));
                donHang.setMaUser(cursor.getInt(1));
                donHang.setMaAdmin(cursor.getString(2));
                donHang.setNgay(cursor.getString(3));
                donHang.setTongTien(cursor.getInt(4));
                donHang.setTrangThai(cursor.getInt(5));
                donHang.setTrangThaiDG(cursor.getInt(6));
                donHang.setGhiChu(cursor.getString(7));
                arr.add(donHang);
                cursor.moveToNext();
            }
        }
        return arr;
    }

    public ArrayList<DonHang> getDHDanggiaoByIDUser( int maUser) {
        String sqlDH = "SELECT * FROM HoaDon WHERE maUser = ? and trangThai = 2";
        Cursor cursor = db.rawQuery(sqlDH,new String[]{String.valueOf(maUser)});
        ArrayList<DonHang> arr = new ArrayList<>();
        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()){
                DonHang donHang = new DonHang();
                donHang.setMaHD(cursor.getInt(0));
                donHang.setMaUser(cursor.getInt(1));
                donHang.setMaAdmin(cursor.getString(2));
                donHang.setNgay(cursor.getString(3));
                donHang.setTongTien(cursor.getInt(4));
                donHang.setTrangThai(cursor.getInt(5));
                donHang.setTrangThaiDG(cursor.getInt(6));
                donHang.setGhiChu(cursor.getString(7));
                arr.add(donHang);
                cursor.moveToNext();
            }
        }
        return arr;
    }

    public ArrayList<DonHang> getDHDagoanthanhByIDUser( int maUser) {
        String sqlDH = "SELECT * FROM HoaDon WHERE maUser = ? and trangThai = 3";
        Cursor cursor = db.rawQuery(sqlDH,new String[]{String.valueOf(maUser)});
        ArrayList<DonHang> arr = new ArrayList<>();
        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()){
                DonHang donHang = new DonHang();
                donHang.setMaHD(cursor.getInt(0));
                donHang.setMaUser(cursor.getInt(1));
                donHang.setMaAdmin(cursor.getString(2));
                donHang.setNgay(cursor.getString(3));
                donHang.setTongTien(cursor.getInt(4));
                donHang.setTrangThai(cursor.getInt(5));
                donHang.setTrangThaiDG(cursor.getInt(6));
                donHang.setGhiChu(cursor.getString(7));
                arr.add(donHang);
                cursor.moveToNext();
            }
        }
        return arr;
    }
    public ArrayList<DonHang> getDHXacnhanbyUser( int maUser) {
        String sqlDH = "SELECT * FROM HoaDon WHERE maUser = ? and trangThai = 1";
        Cursor cursor = db.rawQuery(sqlDH,new String[]{String.valueOf(maUser)});
        ArrayList<DonHang> arr = new ArrayList<>();
        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()){
                DonHang donHang = new DonHang();
                donHang.setMaHD(cursor.getInt(0));
                donHang.setMaUser(cursor.getInt(1));
                donHang.setMaAdmin(cursor.getString(2));
                donHang.setNgay(cursor.getString(3));
                donHang.setTongTien(cursor.getInt(4));
                donHang.setTrangThai(cursor.getInt(5));
                donHang.setTrangThaiDG(cursor.getInt(6));
                donHang.setGhiChu(cursor.getString(7));
                arr.add(donHang);
                cursor.moveToNext();
            }
        }
        return arr;
    }

    public void deleteHoaDonChiTietByMaHD(String maHD) {
        db.delete("HoaDonChiTiet", "maHD=?", new String[]{maHD});
    }

    @SuppressLint("Range")
    public int getTrangThaiDG(int maHD) {
        int trangThaiDG = -1; // Giá trị mặc định khi không tìm thấy mã đơn hàng

        String[] columns = {"trangThaiDG"};
        String selection = "maHD = ?";
        String[] selectionArgs = {String.valueOf(maHD)};

        Cursor cursor = db.query("HoaDon", columns, selection, selectionArgs, null, null, null);

        if (cursor.moveToFirst()) {
            trangThaiDG = cursor.getInt(cursor.getColumnIndex("trangThaiDG"));
        }

        cursor.close();
        return trangThaiDG;
    }

}
